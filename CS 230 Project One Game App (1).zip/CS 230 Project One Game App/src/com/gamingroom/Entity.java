package com.gamingroom;

//Entity class holds the common attributes used in 
public class Entity {
	//class attributes
	protected long id;
	protected String name;
	
	//class constructors
	//Default constructor is protected in order for it to be usable for other subclasses
	protected Entity() {
		
	}
	//class constructor to create Entity instance
	public Entity(long id, String name) {
		this.id = id;
		this.name = name;
		
	}
	
	//getId method used to retrieve Id
	public long getId() {
		return id;
		
	}
	
	//getName method used to retrieve name
	public String getName() {
		return name;
		
		
	}
	
	//toString is being overridden in order to display customized string
	@Override
	public String toString() {
		
		return "Entity [id= " + id + ", name=" + name + "]"; 
		
	}
	

}
