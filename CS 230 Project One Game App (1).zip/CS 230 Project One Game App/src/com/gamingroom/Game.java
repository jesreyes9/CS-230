package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edus
 *
 */
public class Game extends Entity{
	
	// arraylist of teams 
	public static List<Team> teams = new ArrayList<Team>();
	
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
	private Game() {
	}

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}

	public Team addTeam(String name) {
		
		//local team instance
		Team team = null;
		
		//Instancing iterator instance
		Iterator<Team> teamIterator = teams.iterator();
		
		//iterator through teams list to look for existing instance of team name
		while(teamIterator.hasNext()) {
			
			Team tmpTeam = teamIterator.next();
			//look for an already existing instance of team
			if(tmpTeam.getName().equals(name)) {
				team = tmpTeam;
			}
		}
		//if no team is found, create a new team and add to the team list
		if (team == null) {
			
			GameService service = GameService.getInstance();
			
			team = new Team(service.getNextTeamId(),name);
			teams.add(team);
		}
		
		return team;
		
		
	}
	//method override default toString method from Entity class to be customized to Game class

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}
